# FCM Guard — GitHub Actions build

This repository is intentionally set up so the APK can be built entirely from a phone.

## Phone-only build

1. Create a new GitHub repository.
2. Upload:
   - `FCMGuard-source.zip`
   - `.github/workflows/build-apk.yml`
3. Open the repository's **Actions** tab.
4. Select **Build FCM Guard APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed run and download the artifact **FCM-Guard-debug**.
8. Extract it and install `app-debug.apk` on Android.

The APK is a debug APK. Android may ask you to allow installation from the browser/file manager.

## Important

This app does not have privileged/root access. It cannot directly force Google Play services to stay alive or modify Xiaomi PowerKeeper/AppOps arbitrarily. It provides a foreground guard service and shortcuts to the relevant HyperOS settings.
